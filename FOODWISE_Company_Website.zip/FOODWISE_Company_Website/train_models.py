"""Train demand and waste regression pipelines and save evaluation metrics."""
from pathlib import Path
import json
import warnings
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "raw"
MODELS = ROOT / "models"
REPORTS = ROOT / "reports"
MODELS.mkdir(exist_ok=True)
REPORTS.mkdir(exist_ok=True)
warnings.filterwarnings("ignore", category=UserWarning)


def build_pipeline(X: pd.DataFrame, model):
    numeric = X.select_dtypes(include=["number", "bool"]).columns.tolist()
    categorical = [c for c in X.columns if c not in numeric]
    transformers = []
    if numeric:
        transformers.append(("numeric", SimpleImputer(strategy="median"), numeric))
    if categorical:
        cat_pipe = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                             ("encoder", OneHotEncoder(handle_unknown="ignore"))])
        transformers.append(("categorical", cat_pipe, categorical))
    preprocessor = ColumnTransformer(transformers, remainder="drop")
    return Pipeline([("preprocess", preprocessor), ("regressor", model)])


def train_one(filename: str, target: str, model_name: str, date_column: str | None = None):
    path = DATA / filename
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}. Run python generate_demo_data.py")
    df = pd.read_csv(path)
    if target not in df.columns:
        raise ValueError(f"Target '{target}' is missing in {filename}. Columns: {df.columns.tolist()}")
    df = df.dropna(subset=[target]).copy()
    if date_column and date_column in df.columns:
        df[date_column] = pd.to_datetime(df[date_column], errors="coerce")
        df["month"] = df[date_column].dt.month
        df["day_of_week_num"] = df[date_column].dt.dayofweek
        df["is_weekend"] = (df["day_of_week_num"] >= 5).astype(int)
        # Keep chronological order to avoid training on future records.
        df = df.sort_values(date_column)
        X = df.drop(columns=[target, date_column])
        y = df[target].astype(float)
        split = max(1, int(len(df) * 0.8))
        X_train, X_test = X.iloc[:split], X.iloc[split:]
        y_train, y_test = y.iloc[:split], y.iloc[split:]
    else:
        X = df.drop(columns=[target])
        y = df[target].astype(float)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    candidates = {
        "Random Forest": RandomForestRegressor(n_estimators=250, min_samples_leaf=2,
                                               random_state=42, n_jobs=-1),
        "HistGradientBoosting": HistGradientBoostingRegressor(max_iter=180, learning_rate=0.07,
                                                              max_leaf_nodes=20, random_state=42)
    }
    results = []
    best_pipe, best_name, best_rmse = None, None, float("inf")
    for name, estimator in candidates.items():
        pipe = build_pipeline(X_train, estimator)
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        rmse = float(np.sqrt(mean_squared_error(y_test, pred)))
        results.append({"model": name, "MAE": float(mean_absolute_error(y_test, pred)),
                        "RMSE": rmse, "R2": float(r2_score(y_test, pred))})
        if rmse < best_rmse:
            best_pipe, best_name, best_rmse = pipe, name, rmse
    joblib.dump(best_pipe, MODELS / f"{model_name}.joblib")
    report = {"target": target, "selected_model": best_name, "rows": int(len(df)),
              "test_rows": int(len(X_test)), "metrics": results,
              "note": "Metrics depend on dataset quality. Demo datasets are synthetic."}
    (REPORTS / f"{model_name}_metrics.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"\n{model_name.upper()} | selected: {best_name}")
    for result in results:
        print(f"{result['model']}: MAE={result['MAE']:.3f} RMSE={result['RMSE']:.3f} R2={result['R2']:.3f}")
    print(f"Saved: models/{model_name}.joblib")


if __name__ == "__main__":
    train_one("demand.csv", "num_orders", "demand_model", "date")
    train_one("waste.csv", "food_waste_kg", "waste_model", "date")
    print("\nTraining completed. See reports/ for metrics.")
