"""Generate reproducible demo datasets. Replace these with real validated data for final evaluation."""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(42)
dates = pd.date_range("2024-01-01", periods=730, freq="D")

# Demand dataset: daily meal-level records with temporal and promotional features.
rows = []
meal_names = ["Vegetable Rice", "Chicken Rice", "Chapati", "Pasta", "Sandwich"]
for i, date in enumerate(dates):
    for meal_id, meal in enumerate(meal_names, start=1):
        weekend = int(date.dayofweek >= 5)
        promotion = int(rng.random() < 0.18)
        price = float(rng.uniform(45, 120))
        seasonal = 18 * np.sin(2 * np.pi * date.dayofyear / 365.25)
        base = [120, 145, 100, 85, 90][meal_id - 1]
        orders = max(5, int(base + seasonal + 22 * weekend + 35 * promotion - 0.35 * price + rng.normal(0, 15)))
        rows.append({"date": date.date().isoformat(), "meal_id": meal_id, "meal_name": meal,
                    "checkout_price": round(price, 2), "emailer_for_promotion": promotion,
                    "homepage_featured": int(promotion and rng.random() < 0.5),
                    "num_orders": orders})
pd.DataFrame(rows).to_csv(OUT / "demand.csv", index=False)

# Waste dataset: daily kitchen-level records; synthetic for demonstration only.
rows = []
for i, date in enumerate(dates):
    meals = int(rng.integers(140, 360))
    staff = int(rng.integers(3, 11))
    temp = float(rng.uniform(20, 38))
    humidity = float(rng.uniform(35, 90))
    event = int(rng.random() < 0.12)
    previous_waste = float(rng.uniform(3, 28))
    waste = max(0.2, 0.025 * meals + 0.24 * (temp - 25) + 0.06 * (humidity - 55)
                + 2.8 * event + 0.18 * previous_waste - 0.35 * staff + rng.normal(0, 2.2))
    rows.append({"date": date.date().isoformat(), "meals_served": meals, "kitchen_staff": staff,
                "temperature_C": round(temp, 1), "humidity_percent": round(humidity, 1),
                "day_of_week": date.day_name(), "special_event": event,
                "past_waste_kg": round(previous_waste, 2), "food_waste_kg": round(waste, 2)})
pd.DataFrame(rows).to_csv(OUT / "waste.csv", index=False)
print(f"Demo datasets created in {OUT}")
print("demand.csv and waste.csv are synthetic demonstration data, not real-world observations.")
