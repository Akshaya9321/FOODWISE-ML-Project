# FOODWISE — Company-style dashboard UI

This upgraded version adds a polished, company-style Streamlit interface: deep forest-green brand styling, typography, executive dashboard hero, KPI cards, consistent chart styling, and shared UI components across the existing prediction pages.

## Run locally

Open this folder in VS Code, then in the terminal run:

```powershell
python -m pip install -r requirements.txt
python generate_demo_data.py
python train_models.py
python -m streamlit run app.py
```

If `requirements.txt` is nested, first `cd` into the folder containing `app.py` and `requirements.txt`.

## Notes
- This is a local web application, not yet a publicly deployed website.
- Demo data is synthetic and intended for UI demonstration and development.
- For a real company deployment, connect verified datasets, secure authentication, a production database, hosting, and food-safety review.
