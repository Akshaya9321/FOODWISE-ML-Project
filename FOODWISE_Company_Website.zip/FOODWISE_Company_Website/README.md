# FOODWISE — Professional ML Project Starter

**FOODWISE: An Intelligent Food Waste Prediction and Smart Food Redistribution System Using Machine Learning**

This is a modular, runnable project starter for a college ML project. It includes demand forecasting, food-waste estimation, a surplus planning page, model evaluation reports, and a multi-page Streamlit dashboard.

> **Important data note:** The included `data/raw/demand.csv` and `data/raw/waste.csv` are synthetic demo data generated for learning and testing. Do not describe their metrics as real-world performance. Replace them with documented, validated datasets before final evaluation or deployment.

## 1. Open in VS Code
1. Extract the ZIP.
2. In VS Code choose **File → Open Folder** and select the extracted `FOODWISE_Professional` folder (the folder containing `app.py` and `requirements.txt`).
3. Open **Terminal → New Terminal**. Make sure terminal is at the project root.

## 2. Create an environment (recommended)
Windows PowerShell:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```
If activation is blocked, you can still install/run with `python -m pip ...` using the Python interpreter selected in VS Code.

## 3. Generate demo data and train models
```powershell
python generate_demo_data.py
python train_models.py
```
The script trains Random Forest and HistGradientBoosting regressors, selects the lower-RMSE model for each task, saves pipelines under `models/`, and writes holdout metrics under `reports/`.

## 4. Launch the app
```powershell
python -m streamlit run app.py
```
Open the local URL shown in the terminal (usually `http://localhost:8501`).

## 5. Pages
- **Dashboard:** Demand and waste trends, headline metrics.
- **Demand Forecasting:** Predict meal demand from date, meal, price, and promotion features.
- **Waste Prediction:** Estimate waste in kilograms from kitchen and environmental inputs.
- **Smart Redistribution:** Calculate potential surplus after demand buffer and prepare a draft allocation.
- **Model Insights:** View MAE, RMSE and R² from held-out evaluation data.

## 6. Replace demo datasets
Place your validated files in `data/raw/` using these filenames and target columns:
- `demand.csv`: must include target `num_orders`; recommended features include `date`, `meal_id`, `meal_name`, `checkout_price`, `emailer_for_promotion`, `homepage_featured`.
- `waste.csv`: must include target `food_waste_kg`; recommended features include `date`, `meals_served`, `kitchen_staff`, `temperature_C`, `humidity_percent`, `day_of_week`, `special_event`, `past_waste_kg`.

After replacing data, run `python train_models.py` again. Ensure train/test splitting reflects the real use case; demand uses a chronological holdout when a date column is present.

## 7. Current limitations / next professional upgrades
- Redistribution is a draft rule-based allocation, not a live NGO matching service.
- Food safety thresholds are not regulatory guidance. A trained operator must verify handling, temperature, expiry/holding time, allergens, and recipient acceptance.
- The prototype does not yet include login, live location/NGO APIs, cloud deployment, automated retraining, or a production database.
- Before presenting results, document dataset source/licence, cleaning decisions, leakage checks, baseline comparisons, and model limitations.

## Folder structure
```text
FOODWISE_Professional/
├── app.py
├── pages/
├── src/data/               # dataset loading helpers
├── src/services/           # prediction service
├── data/raw/               # demo/validated input CSVs
├── models/                 # trained model pipelines
├── reports/                # evaluation metrics
├── generate_demo_data.py
├── train_models.py
└── requirements.txt
```
