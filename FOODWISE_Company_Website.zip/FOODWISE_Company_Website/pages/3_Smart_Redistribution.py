import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Smart Redistribution | FOODWISE", page_icon="🚚", layout="wide")
from src.ui import load_theme, page_header, footer
load_theme()
st.title("🚚 Smart Surplus & Redistribution Planner")
st.write("Estimate surplus and create a draft allocation. This page is a planning aid; food safety and recipient confirmation are required before distribution.")
with st.form("surplus_form"):
    c1, c2, c3 = st.columns(3)
    prepared = c1.number_input("Prepared servings", min_value=0, value=250, step=10)
    forecast = c2.number_input("Forecast demand (servings)", min_value=0, value=205, step=10)
    buffer = c3.slider("Safety buffer (%)", 0, 25, 5)
    safe_time = st.selectbox("Food safety / holding check", ["Not checked", "Checked — eligible for review", "Not safe to redistribute"])
    submitted = st.form_submit_button("Calculate surplus", type="primary")
if submitted:
    reserved = int(forecast * (1 + buffer / 100))
    surplus = max(0, int(prepared - reserved))
    st.metric("Potential surplus", f"{surplus:,} servings")
    if safe_time != "Checked — eligible for review":
        st.warning("Do not distribute yet. Confirm safe handling, temperature, expiry/holding time, allergen information, and recipient acceptance.")
    elif surplus == 0:
        st.success("No surplus remains after demand and safety buffer.")
    else:
        st.success(f"{surplus} servings are available for a draft redistribution plan, pending final checks.")
        recipients = pd.DataFrame({"Recipient type": ["Community kitchen", "Food donation centre", "Shelter"],
                                  "Suggested share (%)": [50, 30, 20]})
        recipients["Draft servings"] = (recipients["Suggested share (%)"] * surplus / 100).round().astype(int)
        recipients.loc[recipients.index[-1], "Draft servings"] += surplus - recipients["Draft servings"].sum()
        st.dataframe(recipients, use_container_width=True, hide_index=True)
        fig = px.pie(recipients, names="Recipient type", values="Draft servings", title="Draft allocation")
        st.plotly_chart(fig, use_container_width=True)
st.markdown("### Operational checks before handover")
st.markdown("- Food type and allergen details recorded\n- Preparation and holding time checked\n- Required temperature maintained\n- Recipient capacity and pickup confirmed\n- Handover quantity and time logged")
