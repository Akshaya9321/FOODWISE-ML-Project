from datetime import date
import streamlit as st
from src.services.prediction import predict

st.set_page_config(page_title="Demand Forecast | FOODWISE", page_icon="📈", layout="wide")
from src.ui import load_theme, page_header, footer
load_theme()
st.title("📈 Food Demand Forecasting")
st.write("Estimate expected servings for a meal using the trained demand model.")
with st.form("demand_form"):
    col1, col2 = st.columns(2)
    with col1:
        forecast_date = st.date_input("Forecast date", value=date.today())
        meal_name = st.selectbox("Meal", ["Vegetable Rice", "Chicken Rice", "Chapati", "Pasta", "Sandwich"])
        meal_id = {"Vegetable Rice": 1, "Chicken Rice": 2, "Chapati": 3, "Pasta": 4, "Sandwich": 5}[meal_name]
        price = st.number_input("Checkout price", min_value=0.0, value=75.0, step=5.0)
    with col2:
        promo = st.selectbox("Promotion email", [0, 1], format_func=lambda x: "Yes" if x else "No")
        featured = st.selectbox("Homepage featured", [0, 1], format_func=lambda x: "Yes" if x else "No")
    submitted = st.form_submit_button("Forecast demand", type="primary")

if submitted:
    features = {"meal_id": meal_id, "meal_name": meal_name, "checkout_price": price,
                "emailer_for_promotion": promo, "homepage_featured": featured,
                "month": forecast_date.month, "day_of_week_num": forecast_date.weekday(),
                "is_weekend": int(forecast_date.weekday() >= 5)}
    try:
        value = max(0, round(predict("demand_model", features)))
        st.success(f"Estimated demand: **{value:,} servings**")
        st.caption("This is a model estimate, not a guaranteed order count. Accuracy depends on training data and feature coverage.")
    except Exception as e:
        st.error(str(e))
