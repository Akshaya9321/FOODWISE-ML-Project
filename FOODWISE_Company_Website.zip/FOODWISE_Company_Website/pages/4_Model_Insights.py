from pathlib import Path
import json
import streamlit as st
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
st.set_page_config(page_title="Model Insights | FOODWISE", page_icon="🧠", layout="wide")
from src.ui import load_theme, page_header, footer
load_theme()
st.title("🧠 Model Evaluation & Insights")
st.write("Review holdout-set metrics for the trained models. Lower MAE/RMSE is better; R² closer to 1 indicates stronger fit.")
for name, label in [("demand_model_metrics.json", "Demand model"), ("waste_model_metrics.json", "Waste model")]:
    path = REPORTS / name
    st.subheader(label)
    if not path.exists():
        st.info(f"No report yet. Run `python train_models.py` from the project root to train and evaluate {label.lower()}.")
        continue
    report = json.loads(path.read_text(encoding="utf-8"))
    st.caption(f"Selected model: {report['selected_model']} · Rows: {report['rows']} · Test rows: {report['test_rows']}")
    st.dataframe(pd.DataFrame(report["metrics"]), use_container_width=True, hide_index=True)
    st.caption(report.get("note", ""))
