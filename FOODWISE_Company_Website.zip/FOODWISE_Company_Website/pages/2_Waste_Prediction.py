import streamlit as st
from src.services.prediction import predict

st.set_page_config(page_title="Waste Prediction | FOODWISE", page_icon="♻️", layout="wide")
from src.ui import load_theme, page_header, footer
load_theme()
st.title("♻️ Food Waste Prediction")
st.write("Estimate food waste in kilograms from kitchen and environmental conditions.")
with st.form("waste_form"):
    a, b = st.columns(2)
    with a:
        meals = st.number_input("Meals served", min_value=1, value=220, step=10)
        staff = st.number_input("Kitchen staff", min_value=1, value=6)
        temperature = st.number_input("Temperature (°C)", min_value=-5.0, max_value=60.0, value=29.0)
        humidity = st.number_input("Humidity (%)", min_value=0.0, max_value=100.0, value=65.0)
    with b:
        day = st.selectbox("Day of week", ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
        event = st.selectbox("Special event", [0, 1], format_func=lambda x: "Yes" if x else "No")
        past_waste = st.number_input("Previous waste (kg)", min_value=0.0, value=12.0, step=1.0)
    submitted = st.form_submit_button("Estimate food waste", type="primary")
if submitted:
    features = {"meals_served": meals, "kitchen_staff": staff, "temperature_C": temperature,
                "humidity_percent": humidity, "day_of_week": day, "special_event": event,
                "past_waste_kg": past_waste, "month": 6, "day_of_week_num": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].index(day),
                "is_weekend": int(day in ["Saturday", "Sunday"])}
    try:
        waste = max(0, predict("waste_model", features))
        ratio = 100 * waste / max(1, meals)
        st.metric("Predicted food waste", f"{waste:.1f} kg")
        st.metric("Estimated waste per meal", f"{ratio:.1f}%")
        if ratio >= 8:
            st.warning("High waste indicator: review preparation quantity, demand estimate, and storage practices.")
        elif ratio >= 4:
            st.info("Moderate waste indicator: monitor portions and demand changes.")
        else:
            st.success("Low waste indicator based on this prototype's threshold.")
        st.caption("Risk bands are illustrative project thresholds, not a food-safety standard.")
    except Exception as e:
        st.error(str(e))
