from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
MODEL_DIR = ROOT / "models"


def load_model(model_name: str):
    path = MODEL_DIR / f"{model_name}.joblib"
    if not path.exists():
        return None
    return joblib.load(path)


def predict(model_name: str, values: dict):
    model = load_model(model_name)
    if model is None:
        raise FileNotFoundError(f"{model_name} is not trained yet. Run python train_models.py")
    frame = pd.DataFrame([values])
    return float(model.predict(frame)[0])
