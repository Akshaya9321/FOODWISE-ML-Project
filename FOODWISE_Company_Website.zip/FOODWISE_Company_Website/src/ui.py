from pathlib import Path
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]

def load_theme():
    css = r'''<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap');
    :root { --fw-green:#16784b; --fw-deep:#103d2b; --fw-lime:#d8f36a; --fw-ink:#14231c; --fw-muted:#6d7c73; --fw-bg:#f5f8f5; }
    html, body, [class*="css"] {font-family:'DM Sans',sans-serif; color:var(--fw-ink);}
    .stApp {background:linear-gradient(180deg,#f8fbf8 0%,#f2f6f2 100%);}
    [data-testid="stHeader"] {background:rgba(245,248,245,.85);}
    .block-container {max-width:1440px;padding-top:1.8rem;padding-bottom:3rem;}
    [data-testid="stSidebar"] {background:#102f23;border-right:1px solid #214a37;}
    [data-testid="stSidebar"] * {color:#eef7ef!important;}
    [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p {color:#b8d0c0!important;}
    [data-testid="stSidebar"] [data-testid="stRadio"] label {padding:9px 10px;border-radius:10px;}
    h1,h2,h3 {font-family:'Manrope',sans-serif!important;letter-spacing:-.035em;color:#142b20;}
    h1 {font-size:2.45rem!important;font-weight:800!important;}
    h2 {font-weight:750!important;}
    .fw-brand {font-family:'Manrope',sans-serif;font-size:1.35rem;font-weight:800;letter-spacing:-.04em;color:white;margin:.35rem 0 .2rem;}
    .fw-brand span {color:var(--fw-lime);}
    .fw-tag {font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;color:#a6c5b2;font-weight:700;margin-bottom:1.5rem;}
    .fw-eyebrow {font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;font-weight:800;color:var(--fw-green);margin-bottom:.55rem;}
    .fw-subtitle {font-size:1.02rem;color:#65776b;line-height:1.65;max-width:780px;margin-top:-.35rem;margin-bottom:1.6rem;}
    .fw-hero {background:linear-gradient(125deg,#123c2b 0%,#1b6745 65%,#2a8757 100%);border-radius:24px;padding:30px 34px;color:white;position:relative;overflow:hidden;margin-bottom:1.25rem;box-shadow:0 16px 40px rgba(22,83,51,.12);}
    .fw-hero:after {content:'✳';position:absolute;right:28px;top:-35px;font-size:190px;line-height:1;color:rgba(216,243,106,.10);}
    .fw-hero h2 {color:white!important;font-size:2rem!important;margin:.2rem 0 .6rem!important;}
    .fw-hero p {color:#d4e8da;max-width:680px;line-height:1.65;margin:0;}
    .fw-hero .eyebrow {color:#d8f36a;font-size:.72rem;font-weight:800;letter-spacing:.15em;text-transform:uppercase;}
    [data-testid="stMetric"] {background:white;border:1px solid #e3ebe4;border-radius:16px;padding:18px 20px;box-shadow:0 4px 14px rgba(20,50,30,.035);}
    [data-testid="stMetricLabel"] {color:#6d7c73;font-weight:600;}
    [data-testid="stMetricValue"] {color:#173e2b;font-family:'Manrope',sans-serif;font-weight:800;}
    [data-testid="stPlotlyChart"] {background:white;border:1px solid #e4ece5;border-radius:18px;padding:10px;}
    div[data-testid="stForm"] {background:white;border:1px solid #e3ebe4;border-radius:18px;padding:22px;}
    .fw-card {background:white;border:1px solid #e2ebe3;border-radius:18px;padding:20px 22px;height:100%;box-shadow:0 4px 14px rgba(20,50,30,.025);}
    .fw-card .icon {font-size:1.35rem;margin-bottom:.75rem;}
    .fw-card h3 {font-size:1.08rem;margin:.1rem 0 .5rem;}
    .fw-card p {color:#6d7c73;font-size:.92rem;line-height:1.6;margin:0;}
    .fw-section {font-family:'Manrope',sans-serif;font-size:1.3rem;font-weight:800;letter-spacing:-.03em;margin:1.4rem 0 .8rem;}
    .fw-foot {color:#8a998f;font-size:.78rem;border-top:1px solid #e2ebe3;padding-top:1rem;margin-top:2rem;}
    .stButton>button[kind="primary"],.stFormSubmitButton>button {background:#16784b;border:0;border-radius:10px;font-weight:700;padding:.62rem 1.2rem;}
    .stButton>button[kind="primary"]:hover,.stFormSubmitButton>button:hover {background:#105e39;}
    [data-testid="stDataFrame"] {border:1px solid #e3ebe4;border-radius:14px;overflow:hidden;}
    </style>'''
    st.markdown(css, unsafe_allow_html=True)
    with st.sidebar:
        st.markdown('<div class="fw-brand">FOOD<span>WISE</span></div><div class="fw-tag">Food intelligence platform</div>', unsafe_allow_html=True)
        st.markdown('<div style="font-size:.76rem;color:#8eaf9b;letter-spacing:.12em;text-transform:uppercase;font-weight:700;margin:1.2rem 0 .5rem">Workspace</div>', unsafe_allow_html=True)

def page_header(eyebrow, title, subtitle):
    st.markdown(f'<div class="fw-eyebrow">{eyebrow}</div><h1>{title}</h1><div class="fw-subtitle">{subtitle}</div>', unsafe_allow_html=True)

def footer():
    st.markdown('<div class="fw-foot">FOODWISE · Food intelligence for a more sustainable future · Decision-support prototype</div>', unsafe_allow_html=True)
