# FOODWISE Project Scope

## Objective
Use historical food-service data to forecast meal demand, estimate potential food waste, and support safe, responsible surplus redistribution decisions.

## Modules
1. Data ingestion and validation
2. Cleaning and feature engineering
3. Demand forecasting
4. Food-waste regression
5. Evaluation and model comparison
6. Dashboard and prediction interface
7. Rule-based surplus planning with safety checklist

## Evaluation
Report MAE, RMSE and R² on a held-out dataset. For time-dependent demand, use chronological evaluation and avoid using future information in features. Compare against a simple baseline such as last-period or average demand where feasible.

## Responsible use
Model outputs are estimates. Redistribution recommendations must remain subject to food handling requirements, expiry/holding time, temperature, allergen records, recipient capacity, and human approval.
