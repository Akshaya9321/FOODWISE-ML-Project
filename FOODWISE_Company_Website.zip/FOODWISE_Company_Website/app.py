from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st
from src.ui import load_theme, page_header, footer

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "raw"
st.set_page_config(page_title="FOODWISE | Food Intelligence", page_icon="🥬", layout="wide", initial_sidebar_state="expanded")
load_theme()

try:
    demand = pd.read_csv(DATA / "demand.csv", parse_dates=["date"])
    waste = pd.read_csv(DATA / "waste.csv", parse_dates=["date"])
except Exception as exc:
    st.error(f"Unable to load project data: {exc}")
    st.info("Run `python generate_demo_data.py` from the FOODWISE project folder.")
    st.stop()

latest_date = demand.date.max()
latest = demand[demand.date == latest_date]
orders = int(latest.num_orders.sum())
mean_waste = float(waste.food_waste_kg.mean())
prepared = int(orders * 1.12)
surplus = max(0, prepared - orders)

page_header("Overview / Operations", "Food intelligence, at a glance.", "Turn demand signals into smarter preparation, lower waste, and responsible redistribution decisions.")
st.markdown(f'''<div class="fw-hero"><div class="eyebrow">FOODWISE intelligence suite</div><h2>Make every meal count.</h2><p>One connected workspace for demand forecasting, waste-risk estimation, and surplus planning. Monitor your operation and identify opportunities to reduce avoidable food waste.</p></div>''', unsafe_allow_html=True)

cols = st.columns(4)
cols[0].metric("Latest demand", f"{orders:,}", help="Total predicted/recorded servings on the latest date in the demo dataset")
cols[1].metric("Avg. food waste", f"{mean_waste:.1f} kg", help="Average waste in the included demo records")
cols[2].metric("Potential surplus", f"{surplus:,} servings", help="Illustrative preparation buffer; confirm actual prepared quantity")
cols[3].metric("Data observations", f"{len(demand):,}")
st.markdown('<div class="fw-section">Operational performance</div>', unsafe_allow_html=True)
left, right = st.columns([1.55,1])
with left:
    daily = demand.groupby("date", as_index=False).num_orders.sum().tail(45)
    fig = px.area(daily, x="date", y="num_orders", title="Demand trend · recent 45 days", labels={"date":"Date","num_orders":"Servings"})
    fig.update_traces(line=dict(width=2.5), fillcolor="rgba(22,120,75,.12)")
    fig.update_layout(height=340,margin=dict(l=12,r=12,t=58,b=10),paper_bgcolor="white",plot_bgcolor="white",font_color="#52665a",title_font_size=16)
    fig.update_xaxes(showgrid=False); fig.update_yaxes(gridcolor="#edf2ed")
    st.plotly_chart(fig,use_container_width=True)
with right:
    fig2 = px.histogram(waste,x="food_waste_kg",nbins=24,title="Food waste distribution",labels={"food_waste_kg":"Waste (kg)"})
    fig2.update_traces(marker_color="#74a98a")
    fig2.update_layout(height=340,margin=dict(l=12,r=12,t=58,b=10),paper_bgcolor="white",plot_bgcolor="white",font_color="#52665a",title_font_size=16)
    fig2.update_xaxes(showgrid=False); fig2.update_yaxes(gridcolor="#edf2ed")
    st.plotly_chart(fig2,use_container_width=True)

st.markdown('<div class="fw-section">Intelligence modules</div>',unsafe_allow_html=True)
modules = st.columns(4)
items=[("01","Demand forecasting","Estimate meal demand using historical patterns and operational features."),("02","Waste prediction","Estimate potential waste and identify high-risk operating conditions."),("03","Smart redistribution","Review surplus quantities and plan safe, responsible donation actions."),("04","Model insights","Review model performance, feature importance, and evaluation metrics.")]
for col,(num,title,desc) in zip(modules,items):
    with col: st.markdown(f'<div class="fw-card"><div class="icon">✳ <span style="font-size:.7rem;color:#8ca092">{num}</span></div><h3>{title}</h3><p>{desc}</p></div>',unsafe_allow_html=True)
st.markdown('<div class="fw-section">Recent demand records</div>',unsafe_allow_html=True)
st.dataframe(latest.head(10),use_container_width=True,hide_index=True)
st.caption("Surplus figures are illustrative and are not food-safety clearance. Redistribution requires verification of preparation time, storage conditions, allergen information, and local food-safety requirements.")
footer()
